<?php
/**
 * - Ini adalah file konfigurasi instalasi komponen CiFireCMS.
 * - Komponen   : Podcast
 * - Tanggal    : 2025-08-04 | 12:23 PM
*/

$_config['component_name']  = 'Podcast';
$_config['class_name']      = 'podcast';
$_config['table_name']      = 't_podcast';
$_config['file_sql']        = 't_podcast.sql';
$_config['file_controller'] = 'Podcast.php';
$_config['file_model']      = 'Podcast_model.php';
$_config['dir_views']       = 'podcast';
$_config['file_modjs']      = 'podcast.js';
$_config['mod']             = 'podcast';