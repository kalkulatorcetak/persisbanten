#
# TABLE STRUCTURE FOR: t_podcast
#

DROP TABLE IF EXISTS `t_podcast`;

CREATE TABLE `t_podcast` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_penceramah` int(11) DEFAULT NULL,
  `alias` varchar(100) DEFAULT '',
  `title` varchar(255) DEFAULT '',
  `title_seo` varchar(255) DEFAULT '',
  `link_audio` text NOT NULL,
  `tanggal` datetime NOT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

