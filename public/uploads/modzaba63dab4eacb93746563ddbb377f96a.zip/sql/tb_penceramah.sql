#
# TABLE STRUCTURE FOR: tb_penceramah
#

DROP TABLE IF EXISTS `tb_penceramah`;

CREATE TABLE `tb_penceramah` (
  `id_penceramah` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT '',
  `kategori` varchar(100) DEFAULT '',
  `link_seo` int(100) DEFAULT NULL,
  `gambar` varchar(255) DEFAULT '',
  `urutan` int(2) DEFAULT NULL,
  `active` enum('Y','N') NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id_penceramah`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `tb_penceramah` (`id_penceramah`, `title`, `kategori`, `link_seo`, `gambar`, `urutan`, `active`) VALUES (1, 'Ustadz Kasman', 'Ceramah', 1, 'penceramah/ust_kasman.jpg', 1, 'Y');


