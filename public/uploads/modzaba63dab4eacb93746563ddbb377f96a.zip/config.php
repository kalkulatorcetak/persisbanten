<?php
/**
 * - Ini adalah file konfigurasi instalasi komponen CiFireCMS.
 * - Komponen   : Penceramah
 * - Tanggal    : 2025-08-04 | 11:59 AM
*/

$_config['component_name']  = 'Penceramah';
$_config['class_name']      = 'penceramah';
$_config['table_name']      = 'tb_penceramah';
$_config['file_sql']        = 'tb_penceramah.sql';
$_config['file_controller'] = 'Penceramah.php';
$_config['file_model']      = 'Penceramah_model.php';
$_config['dir_views']       = 'penceramah';
$_config['file_modjs']      = 'penceramah.js';
$_config['mod']             = 'penceramah';